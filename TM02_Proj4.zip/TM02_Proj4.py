string = "Hi Alex WelcomeAlex Bye AlexALEXalex"
print("\nCount for Alex\n")

print(string.count('Alex'))
print("\nCount ignoring the case\n")
string = string.upper()
print(string.count('ALEX'))
