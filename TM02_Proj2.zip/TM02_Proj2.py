marksList = [2,3,4,2,4,5,2,3,6,7,4,7,1,8,9,6,5]
marksList.sort()

marksList = set(marksList)
marksList = list(marksList)
print(marksList[-2])