# Hands-on Assignment 1

num = 2
if (num > 0):
    print("Positive")
elif (num == 0):
    print("zero")
else:
    print("Negative")

# Hands-on Assignment 2

if(num%2 == 0):
    print("Even")
else:
    print("Odd")

# Hands-on Assignment 3

a = 57
b = 42
print(str(a)[-1] == str(b)[-1])

